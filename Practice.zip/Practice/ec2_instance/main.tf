resource "aws_instance" "web_instance"{
    ami = var.ami
    instance_type = var.instance_type
    key_name = var.key_name
    associate_public_ip_address = true
    vpc_security_group_ids = var.security_group
    subnet_id = var.subnet_id

    tags = {
        Name = "web_instance"
    }
}