
module "ec2_instance"{
    source = "./ec2_instance"
    ami = "ami-02d26659fd82cf299"
    instance_type = "t2.micro"
    key_name = "application"
    subnet_id = networking.subnet_id
    security_group = security_group.sg_id
    
}