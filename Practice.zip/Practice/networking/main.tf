# vpc creation
resource "aws_vpc" "my_vpc"{
    cidr_block = "10.0.0.0/16"
    tags = {
        Name = "my_vpc"
    }
}
#internet gateway for vpc 
resource "aws_internet_gateway" "igw" {
    vpc_id = aws_vpc.my_vpc.id

    tags = {
        Name ="my_ig"
    }
}
#public subnet
resource "aws_subnet" "public_subnet"{
    vpc_id = aws_vpc.my_vpc.id
    availbility_zone = "ap-south-1a"
    map_public_ip_on_launch = true
    cidr_block = "10.0.1.0/24"
    tags = {
        Name = "public_subnet"
    }
}
#public route table
resource "aws_route_table" "rt"{
    vpc_id = aws_vpc.my_vpc.id

    route{
        cidr_block = "0.0.0.0/0"
        gateway_id = aws_internet_gateway.igw.id
    }

    tags = {
        Name = "public_rt"
    }
}
# subnet association for public subnet

resource "aws_route_table_association" "public_asso" {
    subnet_id = aws_subnet.public_subnet.id
    route_table_id = aws_route_table.rt.id
}

