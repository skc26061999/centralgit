variable "vpc_id"{
    description = "vpc id from network module"
}