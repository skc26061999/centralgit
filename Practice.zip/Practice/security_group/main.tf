resource "aws_security_group" "sg" {
    Name = "terrafrom_sq"
    description= "allow ssh and http"
    vpc_id = var.vpc_id

    ingress {
        description = "allow ssh"
        from_port= 22
        to_port = 22
        protocol ="tcp"
        cidr_block = ["0.0.0.0/0"]
    }
    ingress {
        description = "allow http"
        from_port= 80
        to_port = 80
        protocol ="tcp"
        cidr_block = ["0.0.0.0/0"]
    }
    egress {
        from_port= 0
        to_port = 0
        protocol ="-1"
        cidr_block = ["0.0.0.0/0"]
    }
    tags = {
        Name = "web_sg"
    }
}